/*
 Navicat MySQL Data Transfer

 Source Server         : localhost_3306
 Source Server Type    : MySQL
 Source Server Version : 80015
 Source Host           : localhost:3306
 Source Schema         : freshfish

 Target Server Type    : MySQL
 Target Server Version : 80015
 File Encoding         : 65001

 Date: 12/04/2019 10:37:14
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for freshicon
-- ----------------------------
DROP TABLE IF EXISTS `freshicon`;
CREATE TABLE `freshicon`  (
  `url` char(50) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `name` varchar(6) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `classify` char(10) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of freshicon
-- ----------------------------
INSERT INTO `freshicon` VALUES ('/images/fruit.jpg', '新鲜水果', 'fruit');
INSERT INTO `freshicon` VALUES ('/images/tomato2.png', '生吃蔬菜', 'vege');
INSERT INTO `freshicon` VALUES ('/images/qingxie2.png', '鲜活水产', 'seafood');
INSERT INTO `freshicon` VALUES ('/images/niurou.jpg', '瘦肥肉肉', 'meat');

-- ----------------------------
-- Table structure for order
-- ----------------------------
DROP TABLE IF EXISTS `order`;
CREATE TABLE `order`  (
  `id` int(10) NOT NULL,
  `name` varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `price` float(10, 2) NULL DEFAULT NULL,
  `number` int(10) NULL DEFAULT NULL,
  `total` float(10, 2) NULL DEFAULT NULL,
  `userid` int(10) NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for sell
-- ----------------------------
DROP TABLE IF EXISTS `sell`;
CREATE TABLE `sell`  (
  `classify` char(10) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `url` char(50) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `name` varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `vip` tinyint(1) NULL DEFAULT NULL,
  `limittime` tinyint(1) NULL DEFAULT NULL,
  `cost` float(10, 2) NULL DEFAULT NULL,
  `cheap` float(10, 2) NULL DEFAULT NULL,
  `selled` float(10, 0) NULL DEFAULT NULL,
  `putontime` datetime(0) NULL DEFAULT NULL
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of sell
-- ----------------------------
INSERT INTO `sell` VALUES ('fruit', '/images/apple.jpg', '苹果200g', 0, 1, 15.00, 14.30, 2000, NULL);
INSERT INTO `sell` VALUES ('fruit', '/images/banana.jpg', '香蕉200g', 0, 1, 12.00, 9.00, 502, NULL);
INSERT INTO `sell` VALUES ('seafood', '/images/yaoxie.jpg', '药蟹500g', 0, 0, 35.00, 35.00, 116, NULL);
INSERT INTO `sell` VALUES ('meat', '/images/zhurou2.jpg', '猪肉300g', 1, 0, 23.00, 22.00, 231, NULL);
INSERT INTO `sell` VALUES ('vege', '/images/tomato.jpg', '番茄200g', 0, 1, 15.00, 13.00, 601, NULL);
INSERT INTO `sell` VALUES ('fish', '/images/qiudaoyu.jpg', '秋刀鱼300g', 0, 0, 25.00, 25.00, 200, NULL);
INSERT INTO `sell` VALUES ('seafood', '/images/balangyu.jpg', '巴浪鱼250g', 0, 1, 15.00, 14.30, 2020, NULL);
INSERT INTO `sell` VALUES ('seafood', '/images/zhangyu.jpg', '章鱼250g', 1, 0, 19.00, 15.00, 522, NULL);

-- ----------------------------
-- Table structure for shoppingcart
-- ----------------------------
DROP TABLE IF EXISTS `shoppingcart`;
CREATE TABLE `shoppingcart`  (
  `name` varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `url` char(50) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `cheap` float(10, 2) NULL DEFAULT NULL,
  `cost` float(10, 2) NULL DEFAULT NULL,
  `number` int(10) NULL DEFAULT NULL,
  `total` float(10, 2) NULL DEFAULT NULL
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for user
-- ----------------------------
DROP TABLE IF EXISTS `user`;
CREATE TABLE `user`  (
  `userid` int(10) NOT NULL,
  `telephone` char(11) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `name` varchar(10) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `password` char(15) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `url` char(50) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  PRIMARY KEY (`userid`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

SET FOREIGN_KEY_CHECKS = 1;
