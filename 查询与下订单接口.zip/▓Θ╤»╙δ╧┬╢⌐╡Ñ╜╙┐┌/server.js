/**
 * 应用程序入口
 */
let fs = require('fs');
let express = require('express');
// 创建app应用
let app = express();
// 加载模板处理模块
let swig = require('swig');

let query = require('./lib/poolQuery.js')

let bodyParser = require('body-parser');
let phoneReg = /^1[3|4|5|7|8][0-9]{9}$/;
// 创建 application/x-www-form-urlencoded 编码解析
let urlencodedParser = bodyParser.urlencoded({
  extended: false
})
const formidable = require('formidable');
let path = require('path');
app.use(bodyParser.json());
app.use('/static', express.static('static'));


app.engine('html', swig.renderFile);

app.set('views', './');
app.set('view engine', 'html');
app.set('view options', {
  layout: false
});

swig.setDefaults({
  cache: false
});
app.all('*', function (req, res, next) {
  res.header("Access-Control-Allow-Origin", "*");
  res.header('Access-Control-Allow-Methods', 'PUT, GET, POST, DELETE, OPTIONS');
  res.header("Access-Control-Allow-Headers", "X-Requested-With");
  res.header('Access-Control-Allow-Headers', 'Content-Type');
  next();
})
app.get('/', function (req, res, next) {
  res.render('index');
})
app.get('/manage', function (req, res, next) {
  res.render('manage');
})

// 获取
app.get('/video', function (req, res, next) {
  let sql = `SELECT v.courseid, v.videoid, src, title, type FROM coursevideo c, video v
        WHERE c.courseid = v.courseid and
            c.videoid = v.videoid and
            c.typeid = v.typeid and
            c.typeid = ${req.query.tpid} and
            c.courseid = ${req.query.csid}`
  // let sql = `getvideo(${req.query.tpid}, ${req.query.csid});`
  query(sql, function (qerr, value, field) {
    if (qerr) console.log(qerr)
    else {
      res.writeHead(200, {
        'Content-Type': 'text/html;charset=utf-8'
      });
      res.end(JSON.stringify(value));
    }
  })
})
app.get('/course', function (req, res, next) {
  let sql = `SELECT c.typeid, courseid, name, src, cost, type, edu
        FROM course c, coursetype v
        WHERE c.typeid = v.typeid
        ORDER BY c.typeid, courseid`
  query(sql, function (qerr, value, field) {
    if (qerr) console.log(qerr)
    else {
      res.writeHead(200, {
        'Content-Type': 'text/html;charset=utf-8'
      });
      res.end(JSON.stringify(value));
    }
  })
})
app.post('/post/register', urlencodedParser, function (req, res, next) {
  let phone_email = req.body.phone_email;
  let psw = req.body.psw;
  let response = {
    message: '',
    status: '',
    user: {
      id: '',
      name: '',
      birthday: '',
      phone: '',
      email: '',
      psw: ''
    }
  }
  let user = {
    phone_email: phone_email,
    psw: psw
  }
  let key;
  if (phoneReg.test(phone_email)) {
    key = 'phone'
  } else {
    key = 'email'
  }
  let id;
  let select;
  select = `select id id
    from usersafe
    where phone = '${phone_email}' or
        email = '${phone_email}'`
  query(select, function (qerr, value, field) {
    if (qerr) console.log(qerr)
    else {
      if (value[0] == null) {
        select = 'select max(id) id from user';
        query(select, function (qerr, value2, field) {
          if (qerr) console.log(qerr);
          else {
            id = parseInt(value2[0].id) + 1;
            let insert = `insert into user (id, psw)
                            values('${id}', '${psw}')`
            query(insert, function (qerr, value, field) {
              if (qerr) console.log(qerr)
              else {
                insert = `insert into usersafe (id, ${key})
                                values('${id}', '${phone_email}')`
                query(insert, function (qerr, value, field) {
                  if (qerr) console.log(qerr)
                  else {
                    response.message = '注册成功';
                    response.status = 'success';
                    response.user = user
                    response.user.id = id
                    res.writeHead(200, {
                      'Content-Type': 'text/html;charset=utf-8'
                    });
                    res.end(JSON.stringify(response));
                  }
                })
              }
            })
          }
        });

      } else {
        response.status = 'fail';
        response.message = '该用户已存在';
        res.writeHead(200, {
          'Content-Type': 'text/html;charset=utf-8'
        });
        res.end(JSON.stringify(response));
      }
    }
  })



})
app.post('/post/login', urlencodedParser, function (req, res, next) {
  let phone_email = req.body.phone_email;
  let psw = req.body.psw;
  let response = {
    message: '',
    status: ''
  }
  let key;
  if (phoneReg.test(phone_email)) {
    key = 'phone'
  } else {
    key = 'email'
  }
  let select = `select user.id, name, psw, phone, email, img, birthday
    from user, usersafe
    where user.id = usersafe.id and
    ${key} = '${phone_email}' and
    psw = '${psw}'`;
  query(select, function (qerr, value, field) {
    if (qerr) {
      console.log(qerr);
    } else {
      if (value[0] != null) {
        response.status = 'success';
        response.message = '登陆成功';
        response.user = value[0];
        let date = response.user.birthday;
        response.user.birthday = date;
        res.writeHead(200, {
          'Content-Type': 'text/html;charset=utf-8'
        });
        res.end(JSON.stringify(response));
      } else {
        response.status = 'fail'
        response.message = '用户名或密码错误'
        res.end(JSON.stringify(response));
      }
    }
  })
})

app.post('/post/uploadImg', function (req, res, next) {
  let form = new formidable.IncomingForm()
  let phone = req.query.username
  let imgUrl = '/static/img/' + phone + '.png'
  console.log(__dirname)
  form.uploadDir = path.normalize(__dirname + '/../static/img') //图片上传目录
  form.parse(req, function (err, fields, files) {
    let oldpath = files.file.path
    let newpath = path.normalize(__dirname + '/../static/img/') + req.query.username + '.png' //给上传的图片重命名
    fs.rename(oldpath, newpath, function (err) {
      let response = {}
      if (err) {
        response.message = '文件上传失败';
        return 0;
      }
      let sql = `update user
                set img = '${imgUrl}'
                where id in(select id from usersafe
                    where phone = '${phone}')`;
      query(sql, function (qerr, value, field) {
        if (qerr) {
          console.log(qerr);
          return 0;
        }
        response.img = imgUrl
        res.end(JSON.stringify(response));
      })
    })
  })
})
app.post('/post/changeItem', urlencodedParser, function (req, res, next) {
  let response = {}
  let id = req.body.id;
  let value = req.body.value;
  let item = req.body.item;
  let table = req.body.table
  let update = `update ${table} set ${item} = '${value}'
        where id = '${id}'`
  query(update, function (qerr, value, field) {
    if (qerr) {
      console.log(qerr)
      return 0;
    }
    response.status = 'success'
    response.message = '更新成功'
    res.end(JSON.stringify(response))
  })
});
app.listen(8088, function () {
  console.log('http://127.0.0.1:8088/');
})
